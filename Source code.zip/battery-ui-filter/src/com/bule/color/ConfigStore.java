package com.bule.color;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class ConfigStore {
    public static final String AUTHORITY =
            ModuleConstants.CONFIG_AUTHORITY;
    public static final Uri HIDDEN_PACKAGES_URI =
            Uri.parse("content://" + AUTHORITY + "/hidden");
    public static final String COLUMN_PACKAGE_NAME = "package_name";
    public static final String COLUMN_HIDE_ENABLED = "hide_enabled";
    public static final String COLUMN_TIME_ENABLED = "time_enabled";
    public static final String COLUMN_TIME_SECONDS = "time_seconds";

    private static final String PREFS_NAME = "hidden_apps";
    private static final String KEY_INITIALIZED = "initialized";
    private static final String KEY_PACKAGES = "packages";
    private static final String KEY_HIDDEN_PACKAGES = "hidden_packages";
    private static final String KEY_TIME_PACKAGES = "time_packages";
    private static final String KEY_TIME_HOURS = "time_hours";
    private static final String KEY_TIME_MINUTES = "time_minutes";
    private static final String KEY_TIME_SECONDS = "time_seconds";
    private static final String KEY_TIME_VALUES = "time_values";
    private static final String KEY_V24_MIGRATED = "v24_migrated";
    private static final String KEY_DEFAULT_SELF_ADDED = "default_self_added";

    private ConfigStore() {
    }

    public static synchronized void ensureInitialized(Context context) {
        SharedPreferences preferences = preferences(context);
        boolean initialized = preferences.getBoolean(KEY_INITIALIZED, false);
        boolean selfAdded = preferences.getBoolean(KEY_DEFAULT_SELF_ADDED, false);
        if (initialized && selfAdded
                && preferences.contains(KEY_HIDDEN_PACKAGES)
                && preferences.contains(KEY_TIME_PACKAGES)
                && preferences.getBoolean(KEY_V24_MIGRATED, false)) {
            return;
        }

        boolean hiddenMissing = !preferences.contains(KEY_HIDDEN_PACKAGES);
        HashSet<String> hidden = readSet(preferences, KEY_HIDDEN_PACKAGES);
        HashSet<String> time = readSet(preferences, KEY_TIME_PACKAGES);
        boolean v24Migrated = preferences.getBoolean(KEY_V24_MIGRATED, false);

        // v2.3 stored all targets in KEY_PACKAGES and changed their displayed time.
        // Preserve that behavior by migrating the old set to the time mode only.
        Set<String> oldPackages = preferences.getStringSet(KEY_PACKAGES, null);
        if (time.isEmpty()) {
            if (oldPackages != null) {
                time.addAll(oldPackages);
            }
        }
        if (!v24Migrated && oldPackages != null) {
            // v2.3 automatically selected the module itself. Its new default
            // belongs only to hidden mode, not to the time mode.
            time.remove(context.getPackageName());
            HashMap<String, Long> migratedTimes = readTimeMap(preferences);
            long oldSeconds = getDisplayTimeSecondsUnsafe(preferences);
            for (String packageName : time) {
                if (!migratedTimes.containsKey(packageName)) {
                    migratedTimes.put(packageName, oldSeconds);
                }
            }
            preferences.edit().putStringSet(
                    KEY_TIME_VALUES, encodeTimeMap(migratedTimes)).apply();
        }

        // The module itself is a one-time default for the hidden mode. Once the user
        // unchecks it, selfAdded prevents a later activity/provider start restoring it.
        if (!selfAdded || hiddenMissing) {
            hidden.add(context.getPackageName());
        }

        preferences.edit()
                .putStringSet(KEY_HIDDEN_PACKAGES, hidden)
                .putStringSet(KEY_TIME_PACKAGES, time)
                .putBoolean(KEY_INITIALIZED, true)
                .putBoolean(KEY_DEFAULT_SELF_ADDED, true)
                .putBoolean(KEY_V24_MIGRATED, true)
                .commit();
    }

    public static synchronized Set<String> getHiddenPackages(Context context) {
        ensureInitialized(context);
        return readSet(preferences(context), KEY_HIDDEN_PACKAGES);
    }

    public static synchronized boolean setHiddenPackages(
            Context context,
            Set<String> packageNames) {
        HashSet<String> sanitized = new HashSet<>();
        if (packageNames != null) {
            for (String packageName : packageNames) {
                if (packageName != null && !packageName.trim().isEmpty()) {
                    sanitized.add(packageName);
                }
            }
        }

        boolean saved = preferences(context).edit()
                .putStringSet(KEY_HIDDEN_PACKAGES, sanitized)
                .putBoolean(KEY_INITIALIZED, true)
                .putBoolean(KEY_DEFAULT_SELF_ADDED, true)
                .commit();

        if (saved) {
            context.getContentResolver().notifyChange(HIDDEN_PACKAGES_URI, null);
        }
        return saved;
    }

    public static synchronized Set<String> getTimePackages(Context context) {
        ensureInitialized(context);
        return readSet(preferences(context), KEY_TIME_PACKAGES);
    }

    public static synchronized boolean setTimePackages(
            Context context,
            Set<String> packageNames) {
        HashSet<String> sanitized = sanitize(packageNames);
        boolean saved = preferences(context).edit()
                .putStringSet(KEY_TIME_PACKAGES, sanitized)
                .putBoolean(KEY_INITIALIZED, true)
                .commit();
        if (saved) {
            context.getContentResolver().notifyChange(HIDDEN_PACKAGES_URI, null);
        }
        return saved;
    }

    public static synchronized long getDisplayTimeSeconds(Context context) {
        ensureInitialized(context);
        SharedPreferences preferences = preferences(context);
        long hours = Math.max(0L, preferences.getLong(KEY_TIME_HOURS, 0L));
        long minutes = clamp(preferences.getLong(KEY_TIME_MINUTES, 0L), 0L, 59L);
        long seconds = clamp(preferences.getLong(KEY_TIME_SECONDS, 0L), 0L, 59L);
        // Saturate instead of overflowing if a user enters a very large hour count.
        if (hours > (Long.MAX_VALUE - minutes * 60L - seconds) / 3600L) {
            return Long.MAX_VALUE;
        }
        return hours * 3600L + minutes * 60L + seconds;
    }

    public static synchronized Map<String, Long> getDisplayTimeSecondsByPackage(
            Context context) {
        ensureInitialized(context);
        return new HashMap<>(readTimeMap(preferences(context)));
    }

    public static synchronized long getDisplayTimeSeconds(
            Context context,
            String packageName) {
        ensureInitialized(context);
        Long value = readTimeMap(preferences(context)).get(packageName);
        return value == null ? getDisplayTimeSeconds(context) : Math.max(0L, value);
    }

    public static synchronized boolean setDisplayTime(
            Context context,
            long hours,
            long minutes,
            long seconds) {
        long safeHours = Math.max(0L, hours);
        long safeMinutes = clamp(minutes, 0L, 59L);
        long safeSeconds = clamp(seconds, 0L, 59L);
        boolean saved = preferences(context).edit()
                .putLong(KEY_TIME_HOURS, safeHours)
                .putLong(KEY_TIME_MINUTES, safeMinutes)
                .putLong(KEY_TIME_SECONDS, safeSeconds)
                .putBoolean(KEY_INITIALIZED, true)
                .commit();
        if (saved) {
            context.getContentResolver().notifyChange(HIDDEN_PACKAGES_URI, null);
        }
        return saved;
    }

    public static synchronized boolean setDisplayTime(
            Context context,
            String packageName,
            long hours,
            long minutes,
            long seconds) {
        if (packageName == null || packageName.trim().isEmpty()) {
            return false;
        }
        long safeHours = Math.max(0L, hours);
        long safeMinutes = clamp(minutes, 0L, 59L);
        long safeSeconds = clamp(seconds, 0L, 59L);
        long total;
        if (safeHours > (Long.MAX_VALUE - safeMinutes * 60L - safeSeconds) / 3600L) {
            total = Long.MAX_VALUE;
        } else {
            total = safeHours * 3600L + safeMinutes * 60L + safeSeconds;
        }
        SharedPreferences preferences = preferences(context);
        HashMap<String, Long> values = readTimeMap(preferences);
        values.put(packageName.trim(), total);
        boolean saved = preferences.edit()
                .putStringSet(KEY_TIME_VALUES, encodeTimeMap(values))
                .putBoolean(KEY_INITIALIZED, true)
                .commit();
        if (saved) {
            context.getContentResolver().notifyChange(HIDDEN_PACKAGES_URI, null);
        }
        return saved;
    }

    private static HashSet<String> readSet(
            SharedPreferences preferences,
            String key) {
        return sanitize(preferences.getStringSet(key, null));
    }

    private static HashSet<String> sanitize(Set<String> values) {
        HashSet<String> result = new HashSet<>();
        if (values != null) {
            for (String value : values) {
                if (value != null && !value.trim().isEmpty()) {
                    result.add(value.trim());
                }
            }
        }
        return result;
    }

    private static HashMap<String, Long> readTimeMap(
            SharedPreferences preferences) {
        HashMap<String, Long> result = new HashMap<>();
        Set<String> encoded = preferences.getStringSet(KEY_TIME_VALUES, null);
        if (encoded == null) {
            return result;
        }
        for (String entry : encoded) {
            if (entry == null) {
                continue;
            }
            int separator = entry.lastIndexOf('=');
            if (separator <= 0 || separator >= entry.length() - 1) {
                continue;
            }
            try {
                String packageName = entry.substring(0, separator).trim();
                long seconds = Long.parseLong(entry.substring(separator + 1));
                if (!packageName.isEmpty()) {
                    result.put(packageName, Math.max(0L, seconds));
                }
            } catch (NumberFormatException ignored) {
            }
        }
        return result;
    }

    private static HashSet<String> encodeTimeMap(Map<String, Long> values) {
        HashSet<String> encoded = new HashSet<>();
        for (Map.Entry<String, Long> entry : values.entrySet()) {
            if (entry.getKey() != null && !entry.getKey().trim().isEmpty()) {
                encoded.add(entry.getKey().trim() + "=" + Math.max(0L,
                        entry.getValue() == null ? 0L : entry.getValue()));
            }
        }
        return encoded;
    }

    private static long getDisplayTimeSecondsUnsafe(SharedPreferences preferences) {
        long hours = Math.max(0L, preferences.getLong(KEY_TIME_HOURS, 0L));
        long minutes = clamp(preferences.getLong(KEY_TIME_MINUTES, 0L), 0L, 59L);
        long seconds = clamp(preferences.getLong(KEY_TIME_SECONDS, 0L), 0L, 59L);
        if (hours > (Long.MAX_VALUE - minutes * 60L - seconds) / 3600L) {
            return Long.MAX_VALUE;
        }
        return hours * 3600L + minutes * 60L + seconds;
    }

    private static long clamp(long value, long min, long max) {
        return Math.max(min, Math.min(max, value));
    }

    private static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
}
