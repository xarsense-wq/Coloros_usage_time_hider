package com.bule.color;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class BatteryUiFilter implements IXposedHookLoadPackage {
    private static final String TAG = "ColorOSBatteryFilter";
    private static final String CONFIG_CALL_METHOD = "get_config_v1";
    private static final Pattern DURATION_PART = Pattern.compile(
            "([0-9][0-9,]*)\\s*(小时|时|分钟|分|秒)");
    private static final Map<Object, DetailTimeState> DETAIL_TIME_STATES =
            Collections.synchronizedMap(new WeakHashMap<Object, DetailTimeState>());
    private static final ThreadLocal<ActiveDetailOverride> ACTIVE_DETAIL_OVERRIDE =
            new ThreadLocal<>();
    private static final Map<String, AppTimeSnapshot> APP_TIME_SNAPSHOTS =
            Collections.synchronizedMap(new LinkedHashMap<String, AppTimeSnapshot>() {
                @Override
                protected boolean removeEldestEntry(
                        Map.Entry<String, AppTimeSnapshot> eldest) {
                    return size() > 8;
                }
            });
    private static volatile AppTimeSnapshot lastAppTimeSnapshot;
    private static volatile DisplayConfig lastDisplayConfig = emptyDisplayConfig();
    private static volatile GlobalOnTimeOverride globalOnTimeOverride;
    private static volatile ClassLoader targetClassLoader;
    private static volatile Context processContext;
    private static volatile boolean configErrorLogged;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!ModuleConstants.BATTERY_PACKAGE.equals(lpparam.packageName)
                || !ModuleConstants.BATTERY_UI_PROCESS.equals(lpparam.processName)) {
            return;
        }

        targetClassLoader = lpparam.classLoader;
        processContext = resolveProcessContext();

        installListHook(lpparam);
        installRawAppStatsHook(lpparam);
        installDetailTimeHooks(lpparam);
        installDetailFragmentHooks(lpparam);
        installGlobalScreenTimeHook(lpparam);
    }

    private static void installListHook(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                    ModuleConstants.BATTERY_LIST_CLASS,
                    lpparam.classLoader,
                    ModuleConstants.BATTERY_LIST_METHOD,
                    List.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            Object value = param.args[0];
                            if (!(value instanceof List<?>)) {
                                return;
                            }

                            List<?> source = (List<?>) value;
                            DisplayConfig config = loadConfig(param.thisObject);
                            lastDisplayConfig = config;
                            // Keep a raw per-package foreground snapshot for the
                            // global screen-on calculation. This is captured before
                            // any list item summary is rewritten or removed.
                            captureAppTimeSnapshot(source);
                            if (config.hiddenPackages.isEmpty()
                                    && config.timePackages.isEmpty()) {
                                return;
                            }

                            ArrayList<Object> displayed = new ArrayList<>(source.size());
                            int hidden = 0;
                            int masked = 0;

                            for (Object item : source) {
                                if (isTarget(item, config.hiddenPackages)) {
                                    hidden++;
                                    continue;
                                }
                                displayed.add(item);
                                String timePackage = findTargetPackage(item, config.timePackages);
                                if (timePackage != null
                                        && maskDisplayedTime(item, config.secondsFor(timePackage))) {
                                    masked++;
                                }
                            }

                            if (hidden > 0 || masked > 0) {
                                // Only the list handed to this UI method and the summary
                                // string consumed by the adapter are changed. Raw
                                // BatteryStats values and PowerSipper time fields remain
                                // untouched. A package selected in both modes is hidden.
                                param.args[0] = displayed;
                                XposedBridge.log(TAG + ": hidden " + hidden
                                        + " item(s), masked displayed time for " + masked
                                        + " item(s) using " + config.packageCount()
                                        + " configured package(s) in "
                                        + lpparam.processName);
                            }
                        }
                    });

            XposedBridge.log(TAG + ": list hook installed in " + lpparam.processName);
        } catch (Throwable error) {
            XposedBridge.log(TAG + ": list hook installation failed");
            XposedBridge.log(error);
        }
    }

    private static void installRawAppStatsHook(
            XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                    ModuleConstants.BATTERY_STATS_CLASS,
                    lpparam.classLoader,
                    ModuleConstants.BATTERY_STATS_LIST_METHOD,
                    long.class,
                    long.class,
                    ArrayList.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (param.args == null || param.args.length < 3
                                    || !(param.args[0] instanceof Number)
                                    || !(param.args[1] instanceof Number)
                                    || !(param.args[2] instanceof List<?>)) {
                                return;
                            }
                            DisplayConfig config = loadConfig(param.thisObject);
                            if (config.packageCount() > 0) {
                                lastDisplayConfig = config;
                            }
                            captureAppTimeSnapshot(
                                    (List<?>) param.args[2],
                                    ((Number) param.args[0]).longValue(),
                                    ((Number) param.args[1]).longValue(),
                                    config);
                        }
                    });
            XposedBridge.log(TAG + ": raw app-stat snapshot hook installed in "
                    + lpparam.processName);
        } catch (Throwable error) {
            XposedBridge.log(TAG + ": raw app-stat snapshot hook installation failed");
            XposedBridge.log(error);
        }

        try {
            XposedHelpers.findAndHookMethod(
                    ModuleConstants.BATTERY_SIPPER_UTIL_CLASS,
                    lpparam.classLoader,
                    ModuleConstants.BATTERY_SIPPER_FILTER_METHOD,
                    ArrayList.class,
                    long.class,
                    long.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            if (param.args == null || param.args.length < 3
                                    || !(param.args[0] instanceof List<?>)
                                    || !(param.args[1] instanceof Number)
                                    || !(param.args[2] instanceof Number)) {
                                return;
                            }
                            // r() has removed entries which ColorOS itself will
                            // not expose, but it has not yet truncated the list to
                            // the first five rows. This is the closest page-level
                            // source for an exact "all displayed apps" delta.
                            DisplayConfig config = loadConfig(param.thisObject);
                            if (config.packageCount() > 0) {
                                lastDisplayConfig = config;
                            }
                            captureAppTimeSnapshot(
                                    (List<?>) param.args[0],
                                    ((Number) param.args[1]).longValue(),
                                    ((Number) param.args[2]).longValue(),
                                    config);
                        }
                    });
            XposedBridge.log(TAG + ": full page app-stat snapshot hook installed in "
                    + lpparam.processName);
        } catch (Throwable error) {
            XposedBridge.log(TAG
                    + ": full page app-stat snapshot hook installation failed");
            XposedBridge.log(error);
        }
    }

    private static void installDetailTimeHooks(
            XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                    ModuleConstants.BATTERY_DETAIL_STATS_CLASS,
                    lpparam.classLoader,
                    ModuleConstants.BATTERY_DETAIL_FOREGROUND_METHOD,
                    String.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            maskDetailForegroundTime(param);
                        }
                    });

            XposedHelpers.findAndHookMethod(
                    ModuleConstants.BATTERY_DETAIL_STATS_CLASS,
                    lpparam.classLoader,
                    ModuleConstants.BATTERY_DETAIL_BACKGROUND_METHOD,
                    String.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            maskDetailBackgroundTime(param);
                        }
                    });

            XposedBridge.log(TAG + ": detail time hooks installed in "
                    + lpparam.processName);
        } catch (Throwable error) {
            // Keep the independently installed list hook working even when a
            // future ColorOS build renames one of the detail setters.
            XposedBridge.log(TAG + ": detail time hook installation failed");
            XposedBridge.log(error);
        }
    }

    private static void installDetailFragmentHooks(
            XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                    ModuleConstants.BATTERY_DETAIL_FRAGMENT_CLASS,
                    lpparam.classLoader,
                    ModuleConstants.BATTERY_DETAIL_TODAY_METHOD,
                    double.class,
                    double.class,
                    long.class,
                    long.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            beginTodayDetailOverride(param);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            endDetailOverride();
                        }
                    });

            Class<?> dayValueClass = Class.forName(
                    ModuleConstants.BATTERY_DETAIL_DAY_VALUE_CLASS,
                    false,
                    lpparam.classLoader);
            XposedHelpers.findAndHookMethod(
                    ModuleConstants.BATTERY_DETAIL_FRAGMENT_CLASS,
                    lpparam.classLoader,
                    ModuleConstants.BATTERY_DETAIL_DAY_METHOD,
                    int.class,
                    dayValueClass,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            beginDayDetailOverride(param);
                        }

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            endDetailOverride();
                        }
                    });

            XposedBridge.log(TAG + ": detail fragment hooks installed in "
                    + lpparam.processName);
        } catch (Throwable error) {
            XposedBridge.log(TAG + ": detail fragment hook installation failed");
            XposedBridge.log(error);
        }
    }

    private static void installGlobalScreenTimeHook(
            XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> summaryClass = Class.forName(
                    ModuleConstants.BATTERY_CURVE_SUMMARY_CLASS,
                    false,
                    lpparam.classLoader);
            XposedHelpers.findAndHookMethod(
                    ModuleConstants.BATTERY_CURVE_CLASS,
                    lpparam.classLoader,
                    ModuleConstants.BATTERY_CURVE_UPDATE_METHOD,
                    long.class,
                    long.class,
                    summaryClass,
                    boolean.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            prepareGlobalOnTimeOverride(param);
                        }
                    });
            XposedBridge.log(TAG + ": global active-time source hook installed in "
                    + lpparam.processName);
        } catch (Throwable error) {
            // The final TextView hook below remains useful on a future build
            // even if the summary method or its parameter class was renamed.
            XposedBridge.log(TAG
                    + ": global active-time source hook installation failed");
            XposedBridge.log(error);
        }

        try {
            XposedHelpers.findAndHookMethod(
                    ModuleConstants.BATTERY_CURVE_CLASS,
                    lpparam.classLoader,
                    ModuleConstants.BATTERY_CURVE_SET_TIME_METHOD,
                    TextView.class,
                    String.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (param.args == null || param.args.length < 2
                                    || !(param.args[0] instanceof TextView)) {
                                return;
                            }
                            TextView valueView = (TextView) param.args[0];
                            String resourceName;
                            try {
                                resourceName = valueView.getResources()
                                        .getResourceEntryName(valueView.getId());
                            } catch (Throwable ignored) {
                                return;
                            }
                            if (!ModuleConstants.SCREEN_ON_TIME_VIEW_ID.equals(resourceName)) {
                                return;
                            }
                            GlobalOnTimeOverride override = globalOnTimeOverride;
                            if (override == null || override.originalMillis < 0L) {
                                return;
                            }
                            long adjustedMillis = computeAdjustedGlobalOnTime(override,
                                    valueView.getContext());
                            String replacement = adjustedMillis <= 0L
                                    ? ""
                                    : formatGlobalTime(
                                    valueView.getContext(), adjustedMillis);
                            param.args[1] = replacement;
                            XposedBridge.log(TAG
                                    + ": screen-on activity time adjusted from "
                                    + override.originalMillis + "ms to "
                                    + adjustedMillis + "ms");
                        }
                    });
            XposedBridge.log(TAG + ": global screen-time TextView hook installed in "
                    + lpparam.processName);
        } catch (Throwable error) {
            XposedBridge.log(TAG
                    + ": global screen-time TextView hook installation failed");
            XposedBridge.log(error);
        }
    }

    private static void prepareGlobalOnTimeOverride(
            XC_MethodHook.MethodHookParam param) {
        globalOnTimeOverride = null;
        if (param.args == null || param.args.length < 4
                || !(param.args[0] instanceof Number)
                || !(param.args[1] instanceof Number)
                || param.args[2] == null
                || !(param.args[3] instanceof Boolean)) {
            return;
        }

        Object summary = param.args[2];
        Object activeTime;
        long originalOn;
        try {
            // Runtime names are s9.k.e -> s9.a.b; JADX displays these as
            // f23330e and f23273b respectively.
            activeTime = XposedHelpers.getObjectField(summary, "e");
            if (activeTime == null) {
                return;
            }
            originalOn = Math.max(0L,
                    XposedHelpers.getLongField(activeTime, "b"));
        } catch (Throwable error) {
            XposedBridge.log(TAG + ": failed to read global active-time summary");
            XposedBridge.log(error);
            return;
        }

        long start = ((Number) param.args[0]).longValue();
        long end = ((Number) param.args[1]).longValue();
        long span = end > start ? end - start : 0L;
        long dayCount = Math.max(1L, span / 86400000L);
        boolean useAverage = ((Boolean) param.args[3]).booleanValue()
                && dayCount > 1L;
        long maximumDisplayMillis = span <= 0L
                ? Long.MAX_VALUE
                : (useAverage ? Math.max(0L, span / dayCount) : span);

        // e0 runs before the fragment hands its freshly loaded list to Y().
        // Store the raw total here and apply the app delta lazily from r(),
        // after Y() has captured the matching interval's per-package values.
        globalOnTimeOverride = new GlobalOnTimeOverride(
                originalOn,
                start,
                end,
                useAverage ? dayCount : 1L,
                maximumDisplayMillis);
    }

    private static long computeAdjustedGlobalOnTime(
            GlobalOnTimeOverride override,
            Object host) {
        AppTimeSnapshot snapshot = APP_TIME_SNAPSHOTS.get(override.key());
        if (snapshot == null) {
            snapshot = lastAppTimeSnapshot;
        }
        DisplayConfig config = snapshot == null ? null : snapshot.config;
        if (config == null || config.packageCount() == 0) {
            config = lastDisplayConfig;
        }
        if (config == null || config.packageCount() == 0) {
            config = loadConfig(host);
        }
        if (snapshot == null || config.packageCount() == 0
                || snapshot.foregroundMillisByPackage.isEmpty()) {
            return override.originalMillis;
        }

        BigInteger delta = BigInteger.ZERO;
        HashSet<String> considered = new HashSet<>();
        considered.addAll(config.hiddenPackages);
        considered.addAll(config.timePackages);
        for (String packageName : considered) {
            Long originalValue = snapshot.foregroundMillisByPackage.get(packageName);
            if (originalValue == null) {
                // The ranking list can be empty for an app with no activity in
                // this interval. In that case there is no visible contribution
                // to replace, so do not invent time in the global counter.
                continue;
            }
            long replacement = config.hiddenPackages.contains(packageName)
                    ? 0L
                    : secondsToMillis(config.secondsFor(packageName));
            delta = delta.add(BigInteger.valueOf(replacement))
                    .subtract(BigInteger.valueOf(Math.max(0L, originalValue)));
        }
        if (override.averageDivisor > 1L) {
            delta = divideRounded(delta,
                    BigInteger.valueOf(override.averageDivisor));
        }

        BigInteger adjusted = BigInteger.valueOf(override.originalMillis).add(delta);
        if (adjusted.signum() < 0) {
            adjusted = BigInteger.ZERO;
        }
        BigInteger maximum = BigInteger.valueOf(Long.MAX_VALUE);
        if (adjusted.compareTo(maximum) > 0) {
            adjusted = maximum;
        }
        BigInteger intervalMaximum = BigInteger.valueOf(
                override.maximumDisplayMillis);
        if (adjusted.compareTo(intervalMaximum) > 0) {
            adjusted = intervalMaximum;
        }
        long adjustedMillis = adjusted.longValue();
        XposedBridge.log(TAG + ": global screen-on calculation delta="
                + delta + "ms, original=" + override.originalMillis + "ms, adjusted="
                + adjustedMillis + "ms");
        return adjustedMillis;
    }

    private static BigInteger divideRounded(BigInteger value, BigInteger divisor) {
        if (divisor.signum() <= 0) {
            return value;
        }
        BigInteger[] parts = value.divideAndRemainder(divisor);
        BigInteger remainder = parts[1].abs().shiftLeft(1);
        if (remainder.compareTo(divisor.abs()) >= 0) {
            return parts[0].add(value.signum() < 0 ? BigInteger.ONE.negate()
                    : BigInteger.ONE);
        }
        return parts[0];
    }

    private static void beginTodayDetailOverride(
            XC_MethodHook.MethodHookParam param) {
        ACTIVE_DETAIL_OVERRIDE.remove();
        if (param.args == null || param.args.length < 4) {
            return;
        }
        long originalForegroundMillis = numberAsLong(param.args[2]);
        long originalBackgroundMillis = numberAsLong(param.args[3]);
        ActiveDetailOverride override = createDetailOverride(
                param.thisObject,
                originalForegroundMillis,
                originalBackgroundMillis,
                null);
        if (override == null) {
            return;
        }
        ACTIVE_DETAIL_OVERRIDE.set(override);
        param.args[2] = secondsToMillis(override.foregroundSeconds);
        param.args[3] = secondsToMillis(override.backgroundSeconds);
    }

    private static void beginDayDetailOverride(
            XC_MethodHook.MethodHookParam param) {
        ACTIVE_DETAIL_OVERRIDE.remove();
        if (param.args == null || param.args.length < 2 || param.args[1] == null) {
            return;
        }
        Object dayValue = param.args[1];
        long originalForegroundMillis;
        long originalBackgroundMillis;
        try {
            originalForegroundMillis = XposedHelpers.getLongField(dayValue, "c");
            originalBackgroundMillis = XposedHelpers.getLongField(dayValue, "d");
        } catch (Throwable error) {
            XposedBridge.log(TAG + ": failed to read detail day values");
            XposedBridge.log(error);
            return;
        }

        ActiveDetailOverride override = createDetailOverride(
                param.thisObject,
                originalForegroundMillis,
                originalBackgroundMillis,
                dayValue);
        if (override == null) {
            return;
        }
        ACTIVE_DETAIL_OVERRIDE.set(override);
        XposedHelpers.setLongField(
                dayValue, "c", secondsToMillis(override.foregroundSeconds));
        XposedHelpers.setLongField(
                dayValue, "d", secondsToMillis(override.backgroundSeconds));
    }

    private static ActiveDetailOverride createDetailOverride(
            Object fragment,
            long originalForegroundMillis,
            long originalBackgroundMillis,
            Object dayValue) {
        String packageName = readStringField(fragment, "E");
        if (TextUtils.isEmpty(packageName)) {
            return null;
        }
        DisplayConfig config = loadConfig(fragment);
        if (config.hiddenPackages.contains(packageName)
                || !config.timePackages.contains(packageName)) {
            return null;
        }
        long foregroundSeconds = config.secondsFor(packageName);
        long backgroundSeconds = scaleBackgroundFromMillis(
                originalBackgroundMillis,
                originalForegroundMillis,
                foregroundSeconds);
        return new ActiveDetailOverride(
                packageName,
                foregroundSeconds,
                backgroundSeconds,
                dayValue,
                originalForegroundMillis,
                originalBackgroundMillis);
    }

    private static void endDetailOverride() {
        ActiveDetailOverride override = ACTIVE_DETAIL_OVERRIDE.get();
        try {
            if (override != null && override.dayValue != null) {
                XposedHelpers.setLongField(
                        override.dayValue, "c", override.originalForegroundMillis);
                XposedHelpers.setLongField(
                        override.dayValue, "d", override.originalBackgroundMillis);
            }
            if (override != null) {
                XposedBridge.log(TAG + ": detail time masked for "
                        + override.packageName
                        + "; foreground=" + override.foregroundSeconds
                        + "s, background=" + override.backgroundSeconds + "s");
            }
        } finally {
            ACTIVE_DETAIL_OVERRIDE.remove();
        }
    }

    private static void maskDetailForegroundTime(
            XC_MethodHook.MethodHookParam param) {
        ActiveDetailOverride active = ACTIVE_DETAIL_OVERRIDE.get();
        if (active != null) {
            forgetDetailState(param.thisObject);
            param.args[0] = formatDetailTime(active.foregroundSeconds);
            return;
        }
        String packageName = findDetailPackage(param.thisObject);
        if (TextUtils.isEmpty(packageName)) {
            forgetDetailState(param.thisObject);
            return;
        }

        DisplayConfig config = loadConfig(param.thisObject);
        // Hiding has priority over changing time. A hidden package is only
        // removed from the ranking; opening it by another route must not cause
        // this module to rewrite its detail values.
        if (config.hiddenPackages.contains(packageName)
                || !config.timePackages.contains(packageName)) {
            forgetDetailState(param.thisObject);
            return;
        }

        String originalText = stringArgument(param, 0);
        long originalForegroundSeconds = parseDurationSeconds(originalText);
        long configuredForegroundSeconds = config.secondsFor(packageName);
        DETAIL_TIME_STATES.put(param.thisObject, new DetailTimeState(
                packageName,
                originalForegroundSeconds,
                configuredForegroundSeconds));

        param.args[0] = formatDetailTime(configuredForegroundSeconds);
    }

    private static void maskDetailBackgroundTime(
            XC_MethodHook.MethodHookParam param) {
        ActiveDetailOverride active = ACTIVE_DETAIL_OVERRIDE.get();
        if (active != null) {
            forgetDetailState(param.thisObject);
            param.args[0] = formatDetailTime(active.backgroundSeconds);
            return;
        }
        String packageName = findDetailPackage(param.thisObject);
        DetailTimeState state = DETAIL_TIME_STATES.remove(param.thisObject);
        if (state == null || !state.packageName.equals(packageName)) {
            return;
        }

        long originalBackgroundSeconds = parseDurationSeconds(
                stringArgument(param, 0));
        long configuredBackgroundSeconds = scaleBackgroundTime(
                originalBackgroundSeconds,
                state.originalForegroundSeconds,
                state.configuredForegroundSeconds);
        param.args[0] = formatDetailTime(configuredBackgroundSeconds);

        XposedBridge.log(TAG + ": detail time masked for " + packageName
                + "; foreground=" + state.configuredForegroundSeconds
                + "s, background=" + configuredBackgroundSeconds + "s");
    }

    private static void forgetDetailState(Object host) {
        DETAIL_TIME_STATES.remove(host);
    }

    private static String stringArgument(
            XC_MethodHook.MethodHookParam param, int index) {
        if (param.args == null || index < 0 || index >= param.args.length) {
            return null;
        }
        Object value = param.args[index];
        return value instanceof String ? (String) value : null;
    }

    private static long parseDurationSeconds(String value) {
        if (TextUtils.isEmpty(value)) {
            return 0L;
        }
        Matcher matcher = DURATION_PART.matcher(value);
        long total = 0L;
        while (matcher.find()) {
            long amount;
            try {
                amount = Long.parseLong(matcher.group(1).replace(",", ""));
            } catch (NumberFormatException ignored) {
                return Long.MAX_VALUE;
            }
            String unit = matcher.group(2);
            long multiplier;
            if ("小时".equals(unit) || "时".equals(unit)) {
                multiplier = 3600L;
            } else if ("分钟".equals(unit) || "分".equals(unit)) {
                multiplier = 60L;
            } else {
                multiplier = 1L;
            }
            if (amount > (Long.MAX_VALUE - total) / multiplier) {
                return Long.MAX_VALUE;
            }
            total += amount * multiplier;
        }
        return total;
    }

    private static long scaleBackgroundTime(
            long originalBackgroundSeconds,
            long originalForegroundSeconds,
            long configuredForegroundSeconds) {
        if (originalBackgroundSeconds <= 0L
                || originalForegroundSeconds <= 0L
                || configuredForegroundSeconds <= 0L) {
            return 0L;
        }

        // round(originalBg * configuredFg / originalFg), using BigInteger so
        // an intentionally huge hour value cannot wrap a signed long.
        BigInteger denominator = BigInteger.valueOf(originalForegroundSeconds);
        BigInteger numerator = BigInteger.valueOf(originalBackgroundSeconds)
                .multiply(BigInteger.valueOf(configuredForegroundSeconds));
        BigInteger[] quotientAndRemainder = numerator.divideAndRemainder(denominator);
        BigInteger result = quotientAndRemainder[0];
        if (quotientAndRemainder[1].shiftLeft(1).compareTo(denominator) >= 0) {
            result = result.add(BigInteger.ONE);
        }
        BigInteger maximum = BigInteger.valueOf(Long.MAX_VALUE);
        return result.compareTo(maximum) > 0 ? Long.MAX_VALUE : result.longValue();
    }

    private static long scaleBackgroundFromMillis(
            long originalBackgroundMillis,
            long originalForegroundMillis,
            long configuredForegroundSeconds) {
        if (originalBackgroundMillis <= 0L
                || originalForegroundMillis <= 0L
                || configuredForegroundSeconds <= 0L) {
            return 0L;
        }
        BigInteger denominator = BigInteger.valueOf(originalForegroundMillis);
        BigInteger numerator = BigInteger.valueOf(originalBackgroundMillis)
                .multiply(BigInteger.valueOf(configuredForegroundSeconds));
        BigInteger[] quotientAndRemainder = numerator.divideAndRemainder(denominator);
        BigInteger result = quotientAndRemainder[0];
        if (quotientAndRemainder[1].shiftLeft(1).compareTo(denominator) >= 0) {
            result = result.add(BigInteger.ONE);
        }
        BigInteger maximum = BigInteger.valueOf(Long.MAX_VALUE);
        return result.compareTo(maximum) > 0 ? Long.MAX_VALUE : result.longValue();
    }

    private static long secondsToMillis(long seconds) {
        long safe = Math.max(0L, seconds);
        return safe > Long.MAX_VALUE / 1000L
                ? Long.MAX_VALUE
                : safe * 1000L;
    }

    private static long numberAsLong(Object value) {
        return value instanceof Number ? ((Number) value).longValue() : 0L;
    }

    private static void captureAppTimeSnapshot(List<?> source) {
        captureAppTimeSnapshot(source, Long.MIN_VALUE, Long.MIN_VALUE,
                lastDisplayConfig);
    }

    private static void captureAppTimeSnapshot(
            List<?> source,
            long startMillis,
            long endMillis) {
        captureAppTimeSnapshot(source, startMillis, endMillis, lastDisplayConfig);
    }

    private static void captureAppTimeSnapshot(
            List<?> source,
            long startMillis,
            long endMillis,
            DisplayConfig config) {
        AppTimeSnapshot snapshot;
        if (source == null || source.isEmpty()) {
            snapshot = new AppTimeSnapshot(new HashMap<String, Long>(),
                    startMillis, endMillis, config);
        } else {
            HashMap<String, Long> foregroundMillis = new HashMap<>();
            for (Object item : source) {
                String packageName = packageNameForItem(item);
                if (TextUtils.isEmpty(packageName)) {
                    continue;
                }
                long foreground = Math.max(0L, readLongField(item, "mFGTime"));
                Long previous = foregroundMillis.get(packageName);
                if (previous == null) {
                    foregroundMillis.put(packageName, foreground);
                } else {
                    foregroundMillis.put(packageName,
                            saturatingAdd(previous, foreground));
                }
            }
            snapshot = new AppTimeSnapshot(foregroundMillis,
                    startMillis, endMillis, config);
        }
        lastAppTimeSnapshot = snapshot;
        if (startMillis != Long.MIN_VALUE && endMillis != Long.MIN_VALUE) {
            APP_TIME_SNAPSHOTS.put(snapshot.key(), snapshot);
            XposedBridge.log(TAG + ": captured full app snapshot size="
                    + snapshot.foregroundMillisByPackage.size()
                    + " interval=" + startMillis + ".." + endMillis);
        }
    }

    private static String packageNameForItem(Object item) {
        if (item == null) {
            return null;
        }
        String packageName = readStringField(item, "mPackageName");
        if (!TextUtils.isEmpty(packageName)
                && packageName.indexOf('.') >= 0) {
            return packageName;
        }
        packageName = readStringField(item, "mPackageWithHighestDrain");
        if (!TextUtils.isEmpty(packageName)
                && packageName.indexOf('.') >= 0) {
            return packageName;
        }
        try {
            Object value = XposedHelpers.getObjectField(item, "mApplicationInfo");
            if (value instanceof ApplicationInfo) {
                String applicationPackage = ((ApplicationInfo) value).packageName;
                if (!TextUtils.isEmpty(applicationPackage)) {
                    return applicationPackage;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static long readLongField(Object item, String fieldName) {
        try {
            return XposedHelpers.getLongField(item, fieldName);
        } catch (Throwable ignored) {
            return 0L;
        }
    }

    private static long saturatingAdd(long left, long right) {
        if (right > 0L && left > Long.MAX_VALUE - right) {
            return Long.MAX_VALUE;
        }
        if (right < 0L && left < Long.MIN_VALUE - right) {
            return Long.MIN_VALUE;
        }
        return left + right;
    }

    private static String formatGlobalTime(Context context, long millis) {
        try {
            Class<?> formatter = Class.forName(
                    "t6.h",
                    false,
                    targetClassLoader != null
                            ? targetClassLoader
                            : context.getClass().getClassLoader());
            for (Method method : formatter.getDeclaredMethods()) {
                Class<?>[] parameters = method.getParameterTypes();
                if (!Modifier.isStatic(method.getModifiers())
                        || method.getReturnType() != String.class
                        || parameters.length != 4
                        || !Context.class.isAssignableFrom(parameters[0])
                        || !(parameters[1] == double.class
                        || parameters[1] == Double.class)
                        || parameters[2] != boolean.class
                        || parameters[3] != boolean.class) {
                    continue;
                }
                method.setAccessible(true);
                Object value = method.invoke(null, context, (double) millis,
                        false, true);
                if (value instanceof String) {
                    return (String) value;
                }
            }
        } catch (Throwable error) {
            XposedBridge.log(TAG + ": ColorOS duration formatter lookup failed");
            XposedBridge.log(error);
        }
        return formatDisplayTime(millis / 1000L);
    }

    private static String formatDetailTime(long totalSeconds) {
        long safeSeconds = Math.max(0L, totalSeconds);
        if (safeSeconds == 0L) {
            return "";
        }

        // ColorOS' stock formatter always includes lower zero components
        // (for example "2 小时 0 分 0 秒"). Build the same Chinese detail style
        // from the configured seconds while omitting every zero-value unit.
        long hours = safeSeconds / 3600L;
        long minutes = (safeSeconds % 3600L) / 60L;
        long seconds = safeSeconds % 60L;
        StringBuilder result = new StringBuilder();
        appendDetailPart(result, hours, "小时");
        appendDetailPart(result, minutes, "分");
        appendDetailPart(result, seconds, "秒");
        return result.toString();
    }

    private static void appendDetailPart(
            StringBuilder result, long amount, String unit) {
        if (amount <= 0L) {
            return;
        }
        if (result.length() > 0) {
            result.append(' ');
        }
        result.append(amount).append(' ').append(unit);
    }

    private static String findDetailPackage(Object host) {
        Context context = contextForHost(host);
        Context current = context;
        for (int depth = 0; current != null && depth < 12; depth++) {
            if (current instanceof Activity) {
                Intent intent = ((Activity) current).getIntent();
                return intent == null ? null : intent.getStringExtra("pkgName");
            }
            if (!(current instanceof ContextWrapper)) {
                break;
            }
            Context base = ((ContextWrapper) current).getBaseContext();
            if (base == current) {
                break;
            }
            current = base;
        }
        return null;
    }

    private static Context contextForHost(Object host) {
        if (host instanceof Context) {
            return (Context) host;
        }
        try {
            Object contextObject = XposedHelpers.callMethod(host, "getContext");
            return contextObject instanceof Context ? (Context) contextObject : null;
        } catch (Throwable ignored) {
            return processContext;
        }
    }

    private static Context storageContextVariant(Context context, String methodName) {
        try {
            Method method = Context.class.getMethod(methodName);
            Object value = method.invoke(context);
            return value instanceof Context ? (Context) value : context;
        } catch (Throwable ignored) {
            return context;
        }
    }

    /**
     * Resolve the application context from the battery process itself. Some
     * ColorOS helper objects do not expose getContext(), so relying only on
     * the hook receiver made the provider query look empty at the global
     * screen-time stage even though the list hook could still run.
     */
    private static Context resolveProcessContext() {
        try {
            Class<?> activityThread = Class.forName("android.app.ActivityThread");
            Method currentApplication = activityThread.getDeclaredMethod(
                    "currentApplication");
            currentApplication.setAccessible(true);
            Object value = currentApplication.invoke(null);
            return value instanceof Context ? (Context) value : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static DisplayConfig loadConfig(Object host) {
        DisplayConfig empty = emptyDisplayConfig();

        Cursor cursor = null;
        try {
            Context context = host instanceof Context
                    ? (Context) host
                    : contextForHost(host);
            if (context == null) {
                context = processContext;
            }
            if (context == null) {
                return empty;
            }

            cursor = context.getContentResolver().query(
                    ConfigStore.HIDDEN_PACKAGES_URI,
                    new String[]{
                            ConfigStore.COLUMN_PACKAGE_NAME,
                            ConfigStore.COLUMN_HIDE_ENABLED,
                            ConfigStore.COLUMN_TIME_ENABLED,
                            ConfigStore.COLUMN_TIME_SECONDS
                    },
                    null,
                    null,
                    null);
            HashSet<String> hidden = new HashSet<>();
            HashSet<String> timed = new HashSet<>();
            HashMap<String, Long> timeValues = new HashMap<>();
            if (cursor != null) {
                int packageColumn = cursor.getColumnIndex(
                        ConfigStore.COLUMN_PACKAGE_NAME);
                if (packageColumn >= 0) {
                    int hiddenColumn = cursor.getColumnIndex(
                            ConfigStore.COLUMN_HIDE_ENABLED);
                    int timeColumn = cursor.getColumnIndex(
                            ConfigStore.COLUMN_TIME_ENABLED);
                    int secondsColumn = cursor.getColumnIndex(
                            ConfigStore.COLUMN_TIME_SECONDS);

                    while (cursor.moveToNext()) {
                        String packageName = cursor.getString(packageColumn);
                        if (packageName != null && !packageName.trim().isEmpty()) {
                            if (hiddenColumn >= 0 && cursor.getInt(hiddenColumn) != 0) {
                                hidden.add(packageName);
                            }
                            if (timeColumn >= 0 && cursor.getInt(timeColumn) != 0) {
                                timed.add(packageName);
                            }
                            if (secondsColumn >= 0) {
                                timeValues.put(packageName,
                                        Math.max(0L, cursor.getLong(secondsColumn)));
                            }
                        }
                    }
                }
            }
            DisplayConfig config = new DisplayConfig(hidden, timed, timeValues);
            if (config.packageCount() > 0) {
                XposedBridge.log(TAG + ": loaded " + config.packageCount()
                        + " configured package(s) from provider; hidden=" + hidden.size()
                        + ", time=" + timed.size());
                return config;
            }

            DisplayConfig callConfig = loadConfigViaProviderCall(context);
            if (callConfig.packageCount() > 0) {
                XposedBridge.log(TAG + ": loaded " + callConfig.packageCount()
                        + " configured package(s) via provider call; hidden="
                        + callConfig.hiddenPackages.size() + ", time="
                        + callConfig.timePackages.size());
                return callConfig;
            }

            // Fallback for builds where the cross-package provider is not yet
            // published. This is deliberately after the provider query so a
            // stale package-context preference view cannot hide newer rows.
            try {
                Context moduleContext = context.createPackageContext(
                        "com.bule.color", Context.CONTEXT_IGNORE_SECURITY);
                Context credential = storageContextVariant(
                        moduleContext, "createCredentialProtectedStorageContext");
                Context device = storageContextVariant(
                        moduleContext, "createDeviceProtectedStorageContext");
                Context[] candidates = new Context[]{moduleContext, credential, device};
                DisplayConfig best = config;
                for (Context candidate : candidates) {
                    Set<String> directHidden = ConfigStore.getHiddenPackages(candidate);
                    Set<String> directTimed = ConfigStore.getTimePackages(candidate);
                    Map<String, Long> directValues = ConfigStore
                            .getDisplayTimeSecondsByPackage(candidate);
                    DisplayConfig direct = new DisplayConfig(
                            new HashSet<>(directHidden), new HashSet<>(directTimed),
                            new HashMap<>(directValues));
                    if (direct.packageCount() > best.packageCount()) {
                        best = direct;
                    }
                }
                XposedBridge.log(TAG + ": loaded " + best.packageCount()
                        + " configured package(s) directly from module prefs; hidden="
                        + best.hiddenPackages.size() + ", time="
                        + best.timePackages.size());
                return best;
            } catch (Throwable ignored) {
                return config;
            }
        } catch (Throwable error) {
            if (!configErrorLogged) {
                configErrorLogged = true;
                XposedBridge.log(TAG
                        + ": config query failed; no targets will be filtered");
                XposedBridge.log(error);
            }
            return empty;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private static DisplayConfig loadConfigViaProviderCall(Context context) {
        try {
            Bundle bundle = context.getContentResolver().call(
                    ConfigStore.HIDDEN_PACKAGES_URI,
                    CONFIG_CALL_METHOD,
                    null,
                    null);
            if (bundle == null) {
                return emptyDisplayConfig();
            }
            HashSet<String> hidden = new HashSet<>();
            HashSet<String> timed = new HashSet<>();
            HashMap<String, Long> values = new HashMap<>();
            ArrayList<String> hiddenValues = bundle.getStringArrayList("hidden");
            ArrayList<String> timedValues = bundle.getStringArrayList("timed");
            ArrayList<String> encodedValues = bundle.getStringArrayList("values");
            if (hiddenValues != null) {
                hidden.addAll(hiddenValues);
            }
            if (timedValues != null) {
                timed.addAll(timedValues);
            }
            if (encodedValues != null) {
                for (String encoded : encodedValues) {
                    if (encoded == null) {
                        continue;
                    }
                    int separator = encoded.lastIndexOf('=');
                    if (separator <= 0 || separator >= encoded.length() - 1) {
                        continue;
                    }
                    try {
                        values.put(encoded.substring(0, separator),
                                Math.max(0L, Long.parseLong(
                                        encoded.substring(separator + 1))));
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
            return new DisplayConfig(hidden, timed, values);
        } catch (Throwable ignored) {
            return emptyDisplayConfig();
        }
    }

    private static DisplayConfig emptyDisplayConfig() {
        return new DisplayConfig(
                new HashSet<String>(), new HashSet<String>(),
                new HashMap<String, Long>());
    }

    private static boolean isTarget(Object item, Set<String> hiddenPackages) {
        if (item == null) {
            return false;
        }

        if (hiddenPackages.contains(readStringField(item, "mPackageName"))
                || hiddenPackages.contains(
                        readStringField(item, "mPackageWithHighestDrain"))) {
            return true;
        }

        try {
            Object value = XposedHelpers.getObjectField(item, "mApplicationInfo");
            return value instanceof ApplicationInfo
                    && hiddenPackages.contains(
                            ((ApplicationInfo) value).packageName);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static String findTargetPackage(Object item, Set<String> packages) {
        if (item == null || packages.isEmpty()) {
            return null;
        }
        String packageName = readStringField(item, "mPackageName");
        if (packages.contains(packageName)) {
            return packageName;
        }
        packageName = readStringField(item, "mPackageWithHighestDrain");
        if (packages.contains(packageName)) {
            return packageName;
        }
        try {
            Object value = XposedHelpers.getObjectField(item, "mApplicationInfo");
            if (value instanceof ApplicationInfo
                    && packages.contains(((ApplicationInfo) value).packageName)) {
                return ((ApplicationInfo) value).packageName;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static String readStringField(Object item, String fieldName) {
        try {
            Object value = XposedHelpers.getObjectField(item, fieldName);
            return value instanceof String ? (String) value : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static boolean maskDisplayedTime(Object item, long timeSeconds) {
        String displayTime = formatDisplayTime(timeSeconds);
        try {
            Object summaryObject = XposedHelpers.getObjectField(item, "mSummary");
            String summary = summaryObject instanceof String
                    ? (String) summaryObject
                    : null;
            if (TextUtils.isEmpty(summary)) {
                XposedHelpers.setObjectField(item, "mSummary", displayTime);
                return true;
            }

            int separator = summary.indexOf('|');
            String maskedSummary;
            if (separator >= 0) {
                String prefix = summary.substring(0, separator + 1).trim();
                maskedSummary = displayTime.isEmpty() ? prefix : prefix + "  " + displayTime;
            } else {
                maskedSummary = displayTime;
            }
            XposedHelpers.setObjectField(item, "mSummary", maskedSummary);
            return true;
        } catch (Throwable error) {
            XposedBridge.log(TAG + ": failed to mask displayed time for item");
            XposedBridge.log(error);
            return false;
        }
    }

    private static String formatDisplayTime(long totalSeconds) {
        long safe = Math.max(0L, totalSeconds);
        long hours = safe / 3600L;
        long minutes = (safe % 3600L) / 60L;
        long seconds = safe % 60L;
        // Match the natural ColorOS presentation: omit every zero-value unit.
        // An all-zero configuration leaves the time portion empty, so neither
        // 0小时 nor 0秒 is shown.
        StringBuilder result = new StringBuilder();
        if (hours > 0L) {
            result.append(hours).append("小时");
        }
        if (minutes > 0L) {
            result.append(minutes).append("分钟");
        }
        if (seconds > 0L) {
            result.append(seconds).append("秒");
        }
        return result.toString();
    }

    private static final class DisplayConfig {
        final Set<String> hiddenPackages;
        final Set<String> timePackages;
        final Map<String, Long> timeValues;

        DisplayConfig(
                Set<String> hiddenPackages,
                Set<String> timePackages,
                Map<String, Long> timeValues) {
            this.hiddenPackages = hiddenPackages;
            this.timePackages = timePackages;
            this.timeValues = timeValues;
        }

        long secondsFor(String packageName) {
            Long seconds = timeValues.get(packageName);
            return seconds == null ? 0L : Math.max(0L, seconds);
        }

        int packageCount() {
            HashSet<String> all = new HashSet<>(hiddenPackages);
            all.addAll(timePackages);
            return all.size();
        }
    }

    private static final class AppTimeSnapshot {
        final Map<String, Long> foregroundMillisByPackage;
        final long startMillis;
        final long endMillis;

        final DisplayConfig config;

        AppTimeSnapshot(
                Map<String, Long> foregroundMillisByPackage,
                long startMillis,
                long endMillis,
                DisplayConfig config) {
            this.foregroundMillisByPackage = Collections.unmodifiableMap(
                    new HashMap<>(foregroundMillisByPackage));
            this.startMillis = startMillis;
            this.endMillis = endMillis;
            this.config = config == null ? emptyDisplayConfig() : config;
        }

        String key() {
            return startMillis + ":" + endMillis;
        }
    }

    private static final class GlobalOnTimeOverride {
        final long originalMillis;
        final long startMillis;
        final long endMillis;
        final long averageDivisor;
        final long maximumDisplayMillis;

        GlobalOnTimeOverride(
                long originalMillis,
                long startMillis,
                long endMillis,
                long averageDivisor,
                long maximumDisplayMillis) {
            this.originalMillis = originalMillis;
            this.startMillis = startMillis;
            this.endMillis = endMillis;
            this.averageDivisor = Math.max(1L, averageDivisor);
            this.maximumDisplayMillis = Math.max(0L, maximumDisplayMillis);
        }

        String key() {
            return startMillis + ":" + endMillis;
        }
    }

    private static final class DetailTimeState {
        final String packageName;
        final long originalForegroundSeconds;
        final long configuredForegroundSeconds;

        DetailTimeState(
                String packageName,
                long originalForegroundSeconds,
                long configuredForegroundSeconds) {
            this.packageName = packageName;
            this.originalForegroundSeconds = originalForegroundSeconds;
            this.configuredForegroundSeconds = configuredForegroundSeconds;
        }
    }

    private static final class ActiveDetailOverride {
        final String packageName;
        final long foregroundSeconds;
        final long backgroundSeconds;
        final Object dayValue;
        final long originalForegroundMillis;
        final long originalBackgroundMillis;

        ActiveDetailOverride(
                String packageName,
                long foregroundSeconds,
                long backgroundSeconds,
                Object dayValue,
                long originalForegroundMillis,
                long originalBackgroundMillis) {
            this.packageName = packageName;
            this.foregroundSeconds = foregroundSeconds;
            this.backgroundSeconds = backgroundSeconds;
            this.dayValue = dayValue;
            this.originalForegroundMillis = originalForegroundMillis;
            this.originalBackgroundMillis = originalBackgroundMillis;
        }
    }
}
