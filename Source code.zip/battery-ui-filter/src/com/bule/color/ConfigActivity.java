package com.bule.color;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.res.ColorStateList;

import java.text.Collator;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public final class ConfigActivity extends Activity {
    private static final String STATE_AWAITING_MANUAL_FORCE_STOP =
            "awaiting_manual_force_stop";

    private enum Mode { HIDDEN, TIME }

    private final Set<String> hiddenPackages = new HashSet<>();
    private final Set<String> timePackages = new HashSet<>();
    private final Map<String, Long> timeValues = new HashMap<>();
    private final List<AppItem> installedApps = new ArrayList<>();
    private final ExecutorService loader = Executors.newSingleThreadExecutor();
    private final ExecutorService rootCommands = Executors.newSingleThreadExecutor();

    private AppAdapter adapter;
    private TextView selectionSummary;
    private TextView explanation;
    private Button hiddenModeButton;
    private Button timeModeButton;
    private Mode mode = Mode.HIDDEN;
    private boolean awaitingManualForceStop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getActionBar() != null) {
            getActionBar().hide();
        }

        if (savedInstanceState != null) {
            awaitingManualForceStop = savedInstanceState.getBoolean(
                    STATE_AWAITING_MANUAL_FORCE_STOP,
                    false);
        }

        ConfigStore.ensureInitialized(this);
        hiddenPackages.addAll(ConfigStore.getHiddenPackages(this));
        timePackages.addAll(ConfigStore.getTimePackages(this));
        timeValues.putAll(ConfigStore.getDisplayTimeSecondsByPackage(this));

        getWindow().setStatusBarColor(Color.rgb(32, 20, 58));
        getWindow().setNavigationBarColor(Color.rgb(247, 244, 252));
        getWindow().setDecorFitsSystemWindows(false);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(247, 244, 252));
        root.setOnApplyWindowInsetsListener((view, windowInsets) -> {
            Insets bars = windowInsets.getInsets(WindowInsets.Type.systemBars());
            view.setPadding(
                    dp(16),
                    bars.top + dp(12),
                    dp(16),
                    bars.bottom + dp(12));
            return windowInsets;
        });

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(20), dp(18), dp(20), dp(18));
        hero.setBackground(roundBackground(Color.rgb(44, 27, 78), dp(22)));

        TextView eyebrow = new TextView(this);
        eyebrow.setText("COLOROS LSPOSED · bule不bule");
        eyebrow.setTextColor(Color.rgb(206, 188, 255));
        eyebrow.setTextSize(12);
        eyebrow.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        eyebrow.setLetterSpacing(0.12f);
        hero.addView(eyebrow, matchWrap());

        TextView title = new TextView(this);
        title.setText("ColorOS 屏幕使用时间");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(0, dp(5), 0, dp(2));
        hero.addView(title, matchWrap());

        explanation = new TextView(this);
        explanation.setText("勾选应用后，它会从 ColorOS 电池排行中移除；这里只改变页面列表，不清除系统记录。\n作用域固定为：电池 / com.oplus.battery");
        explanation.setTextColor(Color.rgb(224, 216, 241));
        explanation.setTextSize(13);
        explanation.setLineSpacing(0, 1.08f);
        hero.addView(explanation, matchWrap());
        root.addView(hero, matchWrap());

        LinearLayout summaryCard = new LinearLayout(this);
        summaryCard.setGravity(Gravity.CENTER_VERTICAL);
        summaryCard.setPadding(dp(16), dp(12), dp(16), dp(12));
        summaryCard.setBackground(roundBackground(Color.WHITE, dp(16)));
        LinearLayout.LayoutParams summaryParams = matchWrap();
        summaryParams.setMargins(0, dp(12), 0, 0);
        root.addView(summaryCard, summaryParams);

        TextView summaryDot = new TextView(this);
        summaryDot.setText("●");
        summaryDot.setTextColor(Color.rgb(121, 74, 220));
        summaryDot.setTextSize(18);
        summaryCard.addView(summaryDot, new LinearLayout.LayoutParams(dp(25), dp(32)));

        selectionSummary = new TextView(this);
        selectionSummary.setTextColor(Color.rgb(57, 44, 78));
        selectionSummary.setTextSize(14);
        selectionSummary.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        selectionSummary.setGravity(Gravity.CENTER_VERTICAL);
        summaryCard.addView(selectionSummary, new LinearLayout.LayoutParams(0, dp(42), 1));
        updateSelectionSummary();

        LinearLayout modeBar = new LinearLayout(this);
        modeBar.setOrientation(LinearLayout.HORIZONTAL);
        modeBar.setPadding(dp(4), dp(4), dp(4), dp(4));
        modeBar.setBackground(roundBackground(Color.WHITE, dp(16)));
        LinearLayout.LayoutParams modeBarParams = matchWrap();
        modeBarParams.setMargins(0, dp(10), 0, 0);
        root.addView(modeBar, modeBarParams);

        hiddenModeButton = modeButton("隐藏应用");
        timeModeButton = modeButton("修改显示时间");
        modeBar.addView(hiddenModeButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        modeBar.addView(timeModeButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        hiddenModeButton.setOnClickListener(view -> switchMode(Mode.HIDDEN));
        timeModeButton.setOnClickListener(view -> switchMode(Mode.TIME));

        updateModeUi();

        EditText search = new EditText(this);
        search.setHint("搜索应用名称或包名");
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setTextColor(Color.rgb(45, 37, 58));
        search.setHintTextColor(Color.rgb(137, 126, 151));
        search.setPadding(dp(16), 0, dp(16), 0);
        search.setBackground(roundBackground(Color.WHITE, dp(16)));
        LinearLayout.LayoutParams searchParams = matchWrap();
        searchParams.height = dp(52);
        searchParams.setMargins(0, dp(10), 0, dp(10));
        root.addView(search, searchParams);

        adapter = new AppAdapter();
        ListView list = new ListView(this);
        list.setAdapter(adapter);
        list.setDividerHeight(dp(8));
        list.setDivider(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        list.setClipToPadding(false);
        list.setPadding(0, 0, 0, dp(2));
        list.setOnItemClickListener((parent, view, position, id) -> {
            AppItem item = adapter.getItem(position);
            if (item != null) {
                if (mode == Mode.TIME) {
                    showTimeDialog(item);
                } else {
                    setPackageSelected(item.packageName, !isSelected(item));
                }
            }
        });
        root.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1));

        Button openBattery = new Button(this);
        openBattery.setText("打开 ColorOS 电池页面");
        openBattery.setAllCaps(false);
        openBattery.setTextColor(Color.WHITE);
        openBattery.setTextSize(14);
        openBattery.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        openBattery.setMinHeight(dp(52));
        openBattery.setPadding(dp(12), 0, dp(12), 0);
        openBattery.setBackground(roundBackground(Color.rgb(112, 70, 205), dp(16)));
        openBattery.setOnClickListener(view -> openBatteryPage());
        LinearLayout.LayoutParams buttonParams = matchWrap();
        buttonParams.setMargins(0, dp(12), 0, 0);
        root.addView(openBattery, buttonParams);

        Button restartBattery = new Button(this);
        restartBattery.setText("强行停止并重新打开电池");
        restartBattery.setAllCaps(false);
        restartBattery.setTextColor(Color.rgb(87, 58, 135));
        restartBattery.setTextSize(14);
        restartBattery.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        restartBattery.setMinHeight(dp(50));
        restartBattery.setPadding(dp(12), 0, dp(12), 0);
        restartBattery.setBackground(roundStrokeBackground(Color.TRANSPARENT, Color.rgb(171, 145, 215), dp(16), dp(1)));
        restartBattery.setOnClickListener(view ->
                forceStopAndOpenBattery(restartBattery));
        LinearLayout.LayoutParams restartParams = matchWrap();
        restartParams.setMargins(0, dp(8), 0, 0);
        root.addView(restartBattery, restartParams);

        TextView watermark = new TextView(this);
        watermark.setText("bule不bule");
        watermark.setTextColor(Color.rgb(111, 92, 137));
        watermark.setTextSize(12);
        watermark.setGravity(Gravity.CENTER);
        watermark.setAlpha(0.45f);
        watermark.setLetterSpacing(0.08f);
        watermark.setPadding(0, dp(6), 0, 0);
        root.addView(watermark, matchWrap());

        setContentView(root);

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(
                    CharSequence text,
                    int start,
                    int count,
                    int after) {
            }

            @Override
            public void onTextChanged(
                    CharSequence text,
                    int start,
                    int before,
                    int count) {
                adapter.filter(text == null ? "" : text.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        loadInstalledApplications();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (awaitingManualForceStop) {
            awaitingManualForceStop = false;
            showReopenBatteryPrompt();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putBoolean(
                STATE_AWAITING_MANUAL_FORCE_STOP,
                awaitingManualForceStop);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        loader.shutdownNow();
        rootCommands.shutdownNow();
        super.onDestroy();
    }

    private void loadInstalledApplications() {
        selectionSummary.setText("正在加载应用列表……");

        loader.execute(() -> {
            PackageManager packageManager = getPackageManager();
            List<ApplicationInfo> applications;
            try {
                applications = packageManager.getInstalledApplications(
                        PackageManager.MATCH_DISABLED_COMPONENTS);
            } catch (Throwable error) {
                runOnUiThread(() -> {
                    selectionSummary.setText("应用列表加载失败："
                            + error.getClass().getSimpleName());
                    Toast.makeText(
                            ConfigActivity.this,
                            "读取已安装应用失败",
                            Toast.LENGTH_LONG).show();
                });
                return;
            }
            ArrayList<AppItem> loaded = new ArrayList<>();

            for (ApplicationInfo applicationInfo : applications) {
                if (applicationInfo == null
                        || applicationInfo.packageName == null) {
                    continue;
                }

                String label;
                try {
                    CharSequence rawLabel = applicationInfo.loadLabel(packageManager);
                    label = rawLabel == null
                            ? applicationInfo.packageName
                            : rawLabel.toString();
                } catch (Throwable ignored) {
                    label = applicationInfo.packageName;
                }
                Drawable icon;
                try {
                    icon = applicationInfo.loadIcon(packageManager);
                } catch (Throwable ignored) {
                    icon = packageManager.getDefaultActivityIcon();
                }

                loaded.add(new AppItem(
                        applicationInfo.packageName,
                        label,
                        icon));
            }

            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                installedApps.clear();
                installedApps.addAll(loaded);
                adapter.filter(adapter.query);
                updateSelectionSummary();
            });
        });
    }

    private void setPackageSelected(String packageName, boolean selected) {
        Set<String> selectedPackages = currentPackages();
        boolean wasSelected = selectedPackages.contains(packageName);
        if (selected) {
            selectedPackages.add(packageName);
        } else {
            selectedPackages.remove(packageName);
        }

        boolean saved = mode == Mode.HIDDEN
                ? ConfigStore.setHiddenPackages(this, selectedPackages)
                : ConfigStore.setTimePackages(this, selectedPackages);
        if (!saved) {
            if (wasSelected) {
                selectedPackages.add(packageName);
            } else {
                selectedPackages.remove(packageName);
            }
            Toast.makeText(this, "保存失败，请重试", Toast.LENGTH_SHORT).show();
        }

        updateSelectionSummary();
        adapter.filter(adapter.query);
    }

    private void updateSelectionSummary() {
        if (selectionSummary != null) {
            Set<String> selected = currentPackages();
            String modeName = mode == Mode.HIDDEN ? "隐藏模式" : "时间模式";
            selectionSummary.setText(modeName + " · 已选择 " + selected.size()
                    + " 个应用\n重新打开电池页面后刷新显示");
        }
    }

    private Set<String> currentPackages() {
        return mode == Mode.HIDDEN ? hiddenPackages : timePackages;
    }

    private boolean isSelected(AppItem item) {
        return item != null && currentPackages().contains(item.packageName);
    }

    private void switchMode(Mode nextMode) {
        if (mode == nextMode) {
            return;
        }
        mode = nextMode;
        updateModeUi();
        updateSelectionSummary();
        if (adapter != null) {
            adapter.filter(adapter.query);
        }
    }

    private void updateModeUi() {
        if (hiddenModeButton == null || timeModeButton == null) {
            return;
        }
        boolean hidden = mode == Mode.HIDDEN;
        hiddenModeButton.setTextColor(hidden ? Color.WHITE : Color.rgb(87, 58, 135));
        hiddenModeButton.setBackground(roundBackground(
                hidden ? Color.rgb(112, 70, 205) : Color.TRANSPARENT, dp(13)));
        timeModeButton.setTextColor(hidden ? Color.rgb(87, 58, 135) : Color.WHITE);
        timeModeButton.setBackground(roundBackground(
                hidden ? Color.TRANSPARENT : Color.rgb(112, 70, 205), dp(13)));
        if (explanation != null) {
            explanation.setText(hidden
                    ? "勾选应用后，它会从 ColorOS 电池排行中移除；这里只改变页面列表，不清除系统记录。\n作用域固定为：电池 / com.oplus.battery"
                    : "勾选应用后会单独询问小时、分钟、秒；确认才保存，取消则不勾选。\n作用域固定为：电池 / com.oplus.battery");
        }
    }

    private Button modeButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setMinHeight(0);
        button.setPadding(0, 0, 0, 0);
        return button;
    }

    private EditText timeInput(String hint) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setTextSize(15);
        input.setGravity(Gravity.CENTER);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setSelectAllOnFocus(true);
        input.setTextColor(Color.rgb(45, 37, 58));
        input.setHintTextColor(Color.rgb(137, 126, 151));
        input.setBackground(roundStrokeBackground(
                Color.rgb(249, 247, 252), Color.rgb(209, 196, 231), dp(12), dp(1)));
        return input;
    }

    private void showTimeDialog(AppItem item) {
        if (item == null || mode != Mode.TIME) {
            return;
        }

        LinearLayout fields = new LinearLayout(this);
        fields.setOrientation(LinearLayout.HORIZONTAL);
        fields.setGravity(Gravity.CENTER_VERTICAL);
        fields.setPadding(dp(20), dp(4), dp(20), dp(4));

        EditText hoursInput = timeInput("小时");
        EditText minutesInput = timeInput("分钟");
        EditText secondsInput = timeInput("秒");
        fields.addView(hoursInput, new LinearLayout.LayoutParams(0, dp(52), 1));
        fields.addView(unitLabel("小时"), new LinearLayout.LayoutParams(dp(46), dp(52)));
        fields.addView(minutesInput, new LinearLayout.LayoutParams(0, dp(52), 1));
        fields.addView(unitLabel("分钟"), new LinearLayout.LayoutParams(dp(50), dp(52)));
        fields.addView(secondsInput, new LinearLayout.LayoutParams(0, dp(52), 1));
        fields.addView(unitLabel("秒"), new LinearLayout.LayoutParams(dp(28), dp(52)));

        long totalSeconds = timeValues.containsKey(item.packageName)
                ? Math.max(0L, timeValues.get(item.packageName))
                : ConfigStore.getDisplayTimeSeconds(this);
        hoursInput.setText(String.valueOf(totalSeconds / 3600L));
        minutesInput.setText(String.valueOf((totalSeconds % 3600L) / 60L));
        secondsInput.setText(String.valueOf(totalSeconds % 60L));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("设置「" + item.label + "」显示时间")
                .setMessage("确认后，这个应用会显示为你填写的时长")
                .setView(fields)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存并勾选", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(view -> {
                    long hours = parseLong(hoursInput);
                    long minutes = Math.min(59L, parseLong(minutesInput));
                    long seconds = Math.min(59L, parseLong(secondsInput));
                    if (!ConfigStore.setDisplayTime(
                            this, item.packageName, hours, minutes, seconds)) {
                        Toast.makeText(this, "时间保存失败，请重试", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    long safeHours = Math.max(0L, hours);
                    long total;
                    if (safeHours > (Long.MAX_VALUE - minutes * 60L - seconds) / 3600L) {
                        total = Long.MAX_VALUE;
                    } else {
                        total = safeHours * 3600L + minutes * 60L + seconds;
                    }
                    timeValues.put(item.packageName, total);
                    setPackageSelected(item.packageName, true);
                    dialog.dismiss();
                }));
        dialog.show();
    }

    private TextView unitLabel(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(Color.rgb(87, 70, 111));
        label.setTextSize(12);
        label.setGravity(Gravity.CENTER);
        return label;
    }

    private long parseLong(EditText input) {
        if (input == null || input.getText() == null) {
            return 0L;
        }
        try {
            String value = input.getText().toString().trim();
            if (value.isEmpty()) {
                return 0L;
            }
            return Math.max(0L, Long.parseLong(value));
        } catch (NumberFormatException ignored) {
            return 0L;
        }
    }

    private void openBatteryPage() {
        try {
            Intent intent = new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        } catch (Throwable error) {
            Toast.makeText(
                    this,
                    "无法打开电池页面：" + error.getClass().getSimpleName(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void forceStopAndOpenBattery(Button button) {
        button.setEnabled(false);
        button.setText("正在检查 Root 权限……");

        rootCommands.execute(() -> {
            CommandResult rootCheck = runSuCommand("id -u", 60);
            boolean hasRoot = rootCheck.completed
                    && rootCheck.exitCode == 0
                    && containsRootUid(rootCheck.output);

            boolean restarted = false;
            if (hasRoot) {
                CommandResult forceStop = runSuCommand(
                        "am force-stop " + ModuleConstants.BATTERY_PACKAGE,
                        20);
                restarted = forceStop.completed && forceStop.exitCode == 0;
            }

            boolean finalHasRoot = hasRoot;
            boolean finalRestarted = restarted;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }

                button.setEnabled(true);
                button.setText("强行停止并重新打开电池");

                if (finalRestarted) {
                    Toast.makeText(
                            this,
                            "已强行停止电池，正在重新打开",
                            Toast.LENGTH_SHORT).show();
                    openBatteryPage();
                } else {
                    openBatteryDetailsForManualStop(finalHasRoot);
                }
            });
        });
    }

    private void openBatteryDetailsForManualStop(boolean rootWasAvailable) {
        try {
            awaitingManualForceStop = true;
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse(
                    "package:" + ModuleConstants.BATTERY_PACKAGE));
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            Toast.makeText(
                    this,
                    rootWasAvailable
                            ? "请在应用详情中手动点击“强行停止”"
                            : "未取得 Root，请在应用详情中手动点击“强行停止”",
                    Toast.LENGTH_LONG).show();
            startActivity(intent);
        } catch (Throwable error) {
            awaitingManualForceStop = false;
            Toast.makeText(
                    this,
                    "无法打开电池应用详情："
                            + error.getClass().getSimpleName(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void showReopenBatteryPrompt() {
        new AlertDialog.Builder(this)
                .setTitle("重新进入电池页面")
                .setMessage(
                        "如果你已经在应用详情中点击了“强行停止”，"
                                + "现在重新进入 ColorOS 电池页面即可刷新排行。")
                .setPositiveButton(
                        "重新进入电池页面",
                        (dialog, which) -> openBatteryPage())
                .setNegativeButton("稍后", null)
                .show();
    }

    private static CommandResult runSuCommand(
            String shellCommand,
            long timeoutSeconds) {
        Process process = null;
        try {
            process = new ProcessBuilder("su", "-c", shellCommand)
                    .redirectErrorStream(true)
                    .start();
            boolean completed = process.waitFor(timeoutSeconds, TimeUnit.SECONDS);
            if (!completed) {
                process.destroy();
                return new CommandResult(false, -1, "");
            }

            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(
                            process.getInputStream(),
                            StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (output.length() > 0) {
                        output.append('\n');
                    }
                    output.append(line);
                }
            }
            return new CommandResult(true, process.exitValue(), output.toString());
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            return new CommandResult(false, -1, "");
        } catch (Throwable ignored) {
            return new CommandResult(false, -1, "");
        } finally {
            if (process != null && process.isAlive()) {
                process.destroy();
            }
        }
    }

    private static boolean containsRootUid(String output) {
        if (output == null) {
            return false;
        }
        String[] lines = output.split("[\\r\\n]+");
        for (String line : lines) {
            if ("0".equals(line.trim())) {
                return true;
            }
        }
        return false;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private GradientDrawable roundBackground(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private GradientDrawable roundStrokeBackground(
            int color,
            int strokeColor,
            int radius,
            int strokeWidth) {
        GradientDrawable drawable = roundBackground(color, radius);
        drawable.setStroke(strokeWidth, strokeColor);
        return drawable;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private final class AppAdapter extends BaseAdapter {
        private final List<AppItem> visibleApps = new ArrayList<>();
        private String query = "";

        void filter(String newQuery) {
            query = newQuery == null
                    ? ""
                    : newQuery.trim().toLowerCase(Locale.ROOT);
            visibleApps.clear();

            for (AppItem item : installedApps) {
                if (query.isEmpty()
                        || item.label.toLowerCase(Locale.ROOT).contains(query)
                        || item.packageName.toLowerCase(Locale.ROOT).contains(query)) {
                    visibleApps.add(item);
                }
            }
            Collator collator = Collator.getInstance(Locale.CHINA);
            Collections.sort(visibleApps, new Comparator<AppItem>() {
                @Override
                public int compare(AppItem left, AppItem right) {
                    boolean leftSelected = isSelected(left);
                    boolean rightSelected = isSelected(right);
                    if (leftSelected != rightSelected) {
                        return leftSelected ? -1 : 1;
                    }
                    boolean leftIsModule = getPackageName().equals(left.packageName);
                    boolean rightIsModule = getPackageName().equals(right.packageName);
                    if (leftIsModule != rightIsModule) {
                        return leftIsModule ? -1 : 1;
                    }
                    int labelResult = collator.compare(left.label, right.label);
                    return labelResult != 0
                            ? labelResult
                            : left.packageName.compareTo(right.packageName);
                }
            });
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return visibleApps.size();
        }

        @Override
        public AppItem getItem(int position) {
            if (position < 0 || position >= visibleApps.size()) {
                return null;
            }
            return visibleApps.get(position);
        }

        @Override
        public long getItemId(int position) {
            AppItem item = getItem(position);
            return item == null ? position : item.packageName.hashCode();
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            RowHolder holder;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(ConfigActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(10), dp(8), dp(8), dp(8));
                row.setMinimumHeight(dp(72));
                row.setBackground(roundBackground(Color.WHITE, dp(16)));

                ImageView icon = new ImageView(ConfigActivity.this);
                row.addView(icon, new LinearLayout.LayoutParams(dp(50), dp(50)));

                LinearLayout textColumn = new LinearLayout(ConfigActivity.this);
                textColumn.setOrientation(LinearLayout.VERTICAL);
                LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        1);
                textParams.setMargins(dp(12), 0, dp(8), 0);
                row.addView(textColumn, textParams);

                TextView label = new TextView(ConfigActivity.this);
                label.setTextColor(Color.rgb(45, 37, 58));
                label.setTextSize(16);
                label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                label.setSingleLine(true);
                textColumn.addView(label, matchWrap());

                TextView packageName = new TextView(ConfigActivity.this);
                packageName.setTextColor(Color.rgb(133, 121, 147));
                packageName.setTextSize(12);
                packageName.setSingleLine(true);
                textColumn.addView(packageName, matchWrap());

                CheckBox checkBox = new CheckBox(ConfigActivity.this);
                checkBox.setFocusable(false);
                checkBox.setButtonTintList(new ColorStateList(
                        new int[][]{
                                new int[]{android.R.attr.state_checked},
                                new int[]{}
                        },
                        new int[]{
                                Color.rgb(112, 70, 205),
                                Color.rgb(177, 166, 190)
                        }));
                row.addView(checkBox, new LinearLayout.LayoutParams(dp(48), dp(48)));

                holder = new RowHolder(icon, label, packageName, checkBox);
                row.setTag(holder);
                convertView = row;
            } else {
                holder = (RowHolder) convertView.getTag();
            }

            AppItem item = getItem(position);
            if (item == null) {
                return convertView;
            }

            holder.icon.setImageDrawable(item.icon);
            holder.label.setText(item.label);
            holder.packageName.setText(item.packageName);
            holder.checkBox.setOnCheckedChangeListener(null);
            holder.checkBox.setChecked(isSelected(item));
            holder.checkBox.setOnCheckedChangeListener((button, checked) -> {
                if (mode == Mode.TIME && checked) {
                    // Do not commit the selection until the user confirms a duration.
                    setPackageSelected(item.packageName, false);
                    showTimeDialog(item);
                } else {
                    setPackageSelected(item.packageName, checked);
                }
            });
            return convertView;
        }
    }

    private static final class AppItem {
        final String packageName;
        final String label;
        final Drawable icon;

        AppItem(String packageName, String label, Drawable icon) {
            this.packageName = packageName;
            this.label = label;
            this.icon = icon;
        }
    }

    private static final class RowHolder {
        final ImageView icon;
        final TextView label;
        final TextView packageName;
        final CheckBox checkBox;

        RowHolder(
                ImageView icon,
                TextView label,
                TextView packageName,
                CheckBox checkBox) {
            this.icon = icon;
            this.label = label;
            this.packageName = packageName;
            this.checkBox = checkBox;
        }
    }

    private static final class CommandResult {
        final boolean completed;
        final int exitCode;
        final String output;

        CommandResult(boolean completed, int exitCode, String output) {
            this.completed = completed;
            this.exitCode = exitCode;
            this.output = output;
        }
    }
}
