package com.bule.color;

final class ModuleConstants {
    static final String BATTERY_PACKAGE = "com.oplus.battery";
    static final String BATTERY_UI_PROCESS = BATTERY_PACKAGE + ":ui";
    static final String BATTERY_LIST_CLASS =
            "com.oplus.powermanager.powercurve.graph.SipperListPreference";
    static final String BATTERY_LIST_METHOD = "Y";
    static final String BATTERY_DETAIL_STATS_CLASS =
            "com.oplus.powermanager.fuelgaue.basic.customized.PowerControlStatsPreference";
    // JADX renders these as m16663I/m16659E, but the runtime DEX names are I/E.
    static final String BATTERY_DETAIL_FOREGROUND_METHOD = "I";
    static final String BATTERY_DETAIL_BACKGROUND_METHOD = "E";
    static final String BATTERY_DETAIL_FRAGMENT_CLASS =
            "i9.c1";
    static final String BATTERY_DETAIL_TODAY_METHOD = "J0";
    static final String BATTERY_DETAIL_DAY_METHOD = "H0";
    static final String BATTERY_DETAIL_DAY_VALUE_CLASS =
            "com.oplus.powermanager.fuelgaue.basic.customized.PowerControlBarGraph$a";
    static final String BATTERY_CURVE_CLASS =
            "com.oplus.powermanager.powercurve.graph.PowerCurvePreference";
    // Runtime DEX class used by PowerCurvePreference.e0(long,long,s9.k,boolean).
    static final String BATTERY_CURVE_SUMMARY_CLASS = "s9.k";
    static final String BATTERY_CURVE_UPDATE_METHOD = "e0";
    static final String BATTERY_CURVE_SET_TIME_METHOD = "r";
    static final String BATTERY_STATS_CLASS = "s9.j";
    static final String BATTERY_STATS_LIST_METHOD = "H";
    static final String BATTERY_SIPPER_UTIL_CLASS =
            "com.oplus.powermanager.powercurve.util.a";
    static final String BATTERY_SIPPER_FILTER_METHOD = "r";
    static final String SCREEN_ON_TIME_VIEW_ID = "screen_on_time";
    static final String CONFIG_AUTHORITY =
            "com.bule.color.config";

    private ModuleConstants() {
    }
}
