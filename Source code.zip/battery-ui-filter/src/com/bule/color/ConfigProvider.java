package com.bule.color;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.os.Bundle;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class ConfigProvider extends ContentProvider {
    private static final String METHOD_GET_CONFIG = "get_config_v1";
    private static final String KEY_HIDDEN = "hidden";
    private static final String KEY_TIMED = "timed";
    private static final String KEY_VALUES = "values";
    @Override
    public boolean onCreate() {
        if (getContext() == null) {
            return false;
        }
        ConfigStore.ensureInitialized(getContext());
        return true;
    }

    @Override
    public Cursor query(
            Uri uri,
            String[] projection,
            String selection,
            String[] selectionArgs,
            String sortOrder) {
        if (getContext() == null || !isHiddenPackagesUri(uri)) {
            throw new IllegalArgumentException("Unsupported URI: " + uri);
        }

        Set<String> hidden = ConfigStore.getHiddenPackages(getContext());
        Set<String> timed = ConfigStore.getTimePackages(getContext());
        HashSet<String> all = new HashSet<>(hidden);
        all.addAll(timed);
        ArrayList<String> ordered = new ArrayList<>(all);
        Collections.sort(ordered);

        MatrixCursor cursor = new MatrixCursor(
                new String[]{
                        ConfigStore.COLUMN_PACKAGE_NAME,
                        ConfigStore.COLUMN_HIDE_ENABLED,
                        ConfigStore.COLUMN_TIME_ENABLED,
                        ConfigStore.COLUMN_TIME_SECONDS
                },
                ordered.size());
        Map<String, Long> timeValues =
                ConfigStore.getDisplayTimeSecondsByPackage(getContext());
        long defaultTimeSeconds = ConfigStore.getDisplayTimeSeconds(getContext());
        for (String packageName : ordered) {
            Long configuredTime = timeValues.get(packageName);
            cursor.addRow(new Object[]{
                    packageName,
                    hidden.contains(packageName) ? 1 : 0,
                    timed.contains(packageName) ? 1 : 0,
                    configuredTime == null ? defaultTimeSeconds : configuredTime
            });
        }
        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;
    }

    @Override
    public String getType(Uri uri) {
        if (!isHiddenPackagesUri(uri)) {
            throw new IllegalArgumentException("Unsupported URI: " + uri);
        }
        return "vnd.android.cursor.dir/vnd."
                + ConfigStore.AUTHORITY + ".hidden-package";
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        if (!METHOD_GET_CONFIG.equals(method) || getContext() == null) {
            return super.call(method, arg, extras);
        }
        Set<String> hidden = ConfigStore.getHiddenPackages(getContext());
        Set<String> timed = ConfigStore.getTimePackages(getContext());
        Map<String, Long> values = ConfigStore
                .getDisplayTimeSecondsByPackage(getContext());
        Bundle result = new Bundle();
        result.putStringArrayList(KEY_HIDDEN, new ArrayList<>(hidden));
        result.putStringArrayList(KEY_TIMED, new ArrayList<>(timed));
        ArrayList<String> encoded = new ArrayList<>();
        for (Map.Entry<String, Long> entry : values.entrySet()) {
            encoded.add(entry.getKey() + "=" + entry.getValue());
        }
        result.putStringArrayList(KEY_VALUES, encoded);
        return result;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException("Read-only provider");
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        throw new UnsupportedOperationException("Read-only provider");
    }

    @Override
    public int update(
            Uri uri,
            ContentValues values,
            String selection,
            String[] selectionArgs) {
        throw new UnsupportedOperationException("Read-only provider");
    }

    private static boolean isHiddenPackagesUri(Uri uri) {
        return uri != null
                && ConfigStore.AUTHORITY.equals(uri.getAuthority())
                && "/hidden".equals(uri.getPath());
    }
}
