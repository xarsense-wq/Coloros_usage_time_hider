param(
    [string]$SdkRoot,
    [string]$JavaHome,
    [string]$BuildToolsVersion = '35.0.0',
    [string]$PlatformVersion = 'android-35'
)

$ErrorActionPreference = 'Stop'

$moduleRoot = $PSScriptRoot
$workspaceRoot = Split-Path (Split-Path $moduleRoot -Parent) -Parent

if ([string]::IsNullOrWhiteSpace($SdkRoot)) {
    if (![string]::IsNullOrWhiteSpace($env:ANDROID_SDK_ROOT)) {
        $SdkRoot = $env:ANDROID_SDK_ROOT
    } elseif (![string]::IsNullOrWhiteSpace($env:ANDROID_HOME)) {
        $SdkRoot = $env:ANDROID_HOME
    } else {
        $SdkRoot = Join-Path $workspaceRoot 'android-sdk'
    }
}

if ([string]::IsNullOrWhiteSpace($JavaHome)) {
    if (![string]::IsNullOrWhiteSpace($env:JAVA_HOME)) {
        $JavaHome = $env:JAVA_HOME
    } elseif (Test-Path 'C:\Program Files\Zulu\zulu-17') {
        $JavaHome = 'C:\Program Files\Zulu\zulu-17'
    } else {
        $javacCommand = Get-Command javac.exe -ErrorAction Stop
        $JavaHome = Split-Path (Split-Path $javacCommand.Source -Parent) -Parent
    }
}

$androidJar = Join-Path $SdkRoot "platforms\$PlatformVersion\android.jar"
$buildTools = Join-Path $SdkRoot "build-tools\$BuildToolsVersion"
$env:JAVA_HOME = $JavaHome
$buildRoot = Join-Path $moduleRoot 'build'
$stubClasses = Join-Path $buildRoot 'stub-classes'
$moduleClasses = Join-Path $buildRoot 'module-classes'
$dexOut = Join-Path $buildRoot 'dex'
$compiledResources = Join-Path $buildRoot 'compiled-res.zip'
$stubJar = Join-Path $buildRoot 'xposed-stubs.jar'
$moduleJar = Join-Path $buildRoot 'module.jar'
$unsignedApk = Join-Path $buildRoot 'battery-filter-unsigned.apk'
$unalignedApk = Join-Path $buildRoot 'battery-filter-with-dex.apk'
$alignedApk = Join-Path $buildRoot 'battery-filter-aligned.apk'
$signedApk = Join-Path $buildRoot 'ColorOS-App-Usage-Time-Hider-v2.7-auto.apk'
$keystore = Join-Path $buildRoot 'debug.keystore'

$resolvedModuleRoot = [System.IO.Path]::GetFullPath($moduleRoot)
$resolvedBuildRoot = [System.IO.Path]::GetFullPath($buildRoot)
$modulePrefix = $resolvedModuleRoot.TrimEnd('\') + '\'
if (!$resolvedBuildRoot.StartsWith(
        $modulePrefix,
        [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to clean build directory outside module root: $resolvedBuildRoot"
}

$buildProducts = @(
    $stubClasses,
    $moduleClasses,
    $dexOut,
    $compiledResources,
    $stubJar,
    $moduleJar,
    $unsignedApk,
    $unalignedApk,
    $alignedApk,
    $signedApk,
    "$signedApk.idsig"
)
foreach ($buildProduct in $buildProducts) {
    if (Test-Path -LiteralPath $buildProduct) {
        Remove-Item -LiteralPath $buildProduct -Recurse -Force
    }
}

New-Item -ItemType Directory -Force -Path $stubClasses, $moduleClasses, $dexOut | Out-Null

$javac = Join-Path $JavaHome 'bin\javac.exe'
$jar = Join-Path $JavaHome 'bin\jar.exe'
$keytool = Join-Path $JavaHome 'bin\keytool.exe'
$aapt2 = Join-Path $buildTools 'aapt2.exe'
$d8 = Join-Path $buildTools 'd8.bat'
$zipalign = Join-Path $buildTools 'zipalign.exe'
$apksigner = Join-Path $buildTools 'apksigner.bat'

$requiredTools = @($androidJar, $javac, $jar, $keytool, $aapt2, $d8, $zipalign, $apksigner)
foreach ($requiredTool in $requiredTools) {
    if (!(Test-Path -LiteralPath $requiredTool)) {
        throw "Required build dependency not found: $requiredTool"
    }
}

$stubSources = Get-ChildItem (Join-Path $moduleRoot 'stubs') -Recurse -Filter '*.java' |
    Select-Object -ExpandProperty FullName
& $javac -encoding UTF-8 --release 8 -cp $androidJar -d $stubClasses $stubSources
if ($LASTEXITCODE -ne 0) { throw 'Xposed stub compilation failed' }

& $jar cf $stubJar -C $stubClasses .
if ($LASTEXITCODE -ne 0) { throw 'Xposed stub jar creation failed' }

$moduleSources = Get-ChildItem (Join-Path $moduleRoot 'src') -Recurse -Filter '*.java' |
    Select-Object -ExpandProperty FullName
& $javac -encoding UTF-8 --release 8 -cp "$androidJar;$stubJar" -d $moduleClasses $moduleSources
if ($LASTEXITCODE -ne 0) { throw 'Module compilation failed' }

& $jar cf $moduleJar -C $moduleClasses .
if ($LASTEXITCODE -ne 0) { throw 'Module jar creation failed' }

& $aapt2 compile --dir (Join-Path $moduleRoot 'res') -o $compiledResources
if ($LASTEXITCODE -ne 0) { throw 'Resource compilation failed' }

& $aapt2 link -o $unsignedApk -I $androidJar --auto-add-overlay `
    --manifest (Join-Path $moduleRoot 'AndroidManifest.xml') `
    --min-sdk-version 30 --target-sdk-version 35 -R $compiledResources `
    -A (Join-Path $moduleRoot 'assets')
if ($LASTEXITCODE -ne 0) { throw 'APK resource linking failed' }

& $d8 --lib $androidJar --min-api 30 --output $dexOut $moduleJar
if ($LASTEXITCODE -ne 0) { throw 'DEX compilation failed' }

Copy-Item -LiteralPath $unsignedApk -Destination $unalignedApk -Force
& $jar uf $unalignedApk -C $dexOut 'classes.dex'
if ($LASTEXITCODE -ne 0) { throw 'Adding classes.dex failed' }

& $zipalign -f 4 $unalignedApk $alignedApk
if ($LASTEXITCODE -ne 0) { throw 'zipalign failed' }

if (!(Test-Path $keystore)) {
    & $keytool -genkeypair -keystore $keystore -storepass android -keypass android `
        -alias androiddebugkey -dname 'CN=Android Debug,O=Android,C=US' `
        -keyalg RSA -keysize 2048 -validity 10000
    if ($LASTEXITCODE -ne 0) { throw 'Debug keystore generation failed' }
}

& $apksigner sign --ks $keystore --ks-pass pass:android --key-pass pass:android `
    --out $signedApk $alignedApk
if ($LASTEXITCODE -ne 0) { throw 'APK signing failed' }

& $apksigner verify --verbose --print-certs $signedApk
if ($LASTEXITCODE -ne 0) { throw 'APK signature verification failed' }

Write-Output $signedApk
