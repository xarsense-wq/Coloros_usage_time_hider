package de.robv.android.xposed;

public final class XposedHelpers {
    public static XC_MethodHook.Unhook findAndHookMethod(
            String className,
            ClassLoader classLoader,
            String methodName,
            Object... parameterTypesAndCallback) {
        return null;
    }

    public static Object getObjectField(Object instance, String fieldName) {
        return null;
    }

    public static long getLongField(Object instance, String fieldName) {
        return 0L;
    }

    public static void setObjectField(
            Object instance,
            String fieldName,
            Object value) {
    }

    public static void setLongField(
            Object instance,
            String fieldName,
            long value) {
    }

    public static Object callMethod(
            Object instance,
            String methodName,
            Object... args) {
        return null;
    }
}
